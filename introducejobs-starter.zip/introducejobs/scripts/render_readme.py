"""
Regenerates the job listings table inside README.md from jobs.yaml.
Keeps everything between <!-- JOBS:START --> and <!-- JOBS:END --> markers.
Run: python scripts/render_readme.py
"""
import yaml
from pathlib import Path
from collections import defaultdict

JOBS_FILE = Path("jobs.yaml")
README_FILE = Path("README.md")
START_MARKER = "<!-- JOBS:START -->"
END_MARKER = "<!-- JOBS:END -->"


def load_jobs():
    with open(JOBS_FILE, "r") as f:
        jobs = yaml.safe_load(f) or []
    return jobs


def build_table(jobs):
    by_city = defaultdict(list)
    for j in jobs:
        by_city[j.get("city", "Unspecified")].append(j)

    lines = []
    for city in sorted(by_city.keys()):
        lines.append(f"\n### {city}\n")
        lines.append("| Company | Role | Type | Apply | Posted |")
        lines.append("|---|---|---|---|---|")
        for j in sorted(by_city[city], key=lambda x: x.get("posted_date", ""), reverse=True):
            company = j.get("company", "")
            role = j.get("role", "")
            job_type = j.get("type", "")
            link = j.get("apply_link", "")
            posted = j.get("posted_date", "")
            lines.append(f"| {company} | {role} | {job_type} | [Apply]({link}) | {posted} |")
    return "\n".join(lines)


def update_readme(table_md):
    content = README_FILE.read_text()
    start_idx = content.find(START_MARKER)
    end_idx = content.find(END_MARKER)

    if start_idx == -1 or end_idx == -1:
        raise ValueError(
            f"README.md must contain both {START_MARKER} and {END_MARKER} markers."
        )

    new_content = (
        content[: start_idx + len(START_MARKER)]
        + "\n"
        + table_md
        + "\n"
        + content[end_idx:]
    )
    README_FILE.write_text(new_content)


if __name__ == "__main__":
    jobs = load_jobs()
    table_md = build_table(jobs)
    update_readme(table_md)
    print(f"README.md updated with {len(jobs)} listing(s).")
