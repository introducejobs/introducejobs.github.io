"""
Searches X (Twitter) recent posts for hiring-related keywords and appends
candidate listings to jobs_pending_review.yaml for manual review.

This does NOT auto-publish to jobs.yaml. A human (you) reviews
jobs_pending_review.yaml, cleans it up, and moves entries into jobs.yaml
via a normal PR. This keeps quality control in your hands.

Requires: X API Basic tier (or higher) bearer token, set as a GitHub
Actions secret named X_BEARER_TOKEN. Free tier does not support search.

Docs: https://developer.x.com/en/docs/x-api/tweets/search/introduction
"""
import os
import requests
import yaml
from pathlib import Path
from datetime import datetime, timezone

BEARER_TOKEN = os.environ.get("X_BEARER_TOKEN")
SEARCH_URL = "https://api.twitter.com/2/tweets/search/recent"
PENDING_FILE = Path("jobs_pending_review.yaml")

# Tune this. Combine hiring keywords with city names relevant to you.
# X recent search supports OR, AND, exact phrases, and exclusions.
CITIES = ["Indore", "Bangalore", "Mumbai", "Pune", "Delhi", "Remote"]
QUERY = (
    '("we\'re hiring" OR "we are hiring" OR "job opening" OR "hiring for") '
    f'({" OR ".join(CITIES)}) '
    '-is:retweet lang:en'
)


def search_tweets():
    headers = {"Authorization": f"Bearer {BEARER_TOKEN}"}
    params = {
        "query": QUERY,
        "max_results": 25,
        "tweet.fields": "author_id,created_at,text",
        "expansions": "author_id",
        "user.fields": "username,name",
    }
    resp = requests.get(SEARCH_URL, headers=headers, params=params, timeout=30)
    resp.raise_for_status()
    return resp.json()


def load_pending():
    if PENDING_FILE.exists():
        with open(PENDING_FILE, "r") as f:
            return yaml.safe_load(f) or []
    return []


def save_pending(entries):
    with open(PENDING_FILE, "w") as f:
        yaml.dump(entries, f, sort_keys=False, allow_unicode=True)


def already_captured(entries, tweet_id):
    return any(e.get("source_tweet_id") == tweet_id for e in entries)


def main():
    if not BEARER_TOKEN:
        raise SystemExit("X_BEARER_TOKEN environment variable not set.")

    data = search_tweets()
    tweets = data.get("data", [])
    users = {u["id"]: u for u in data.get("includes", {}).get("users", [])}

    pending = load_pending()
    added = 0

    for tweet in tweets:
        tweet_id = tweet["id"]
        if already_captured(pending, tweet_id):
            continue

        author = users.get(tweet["author_id"], {})
        pending.append({
            "company": author.get("name", "Unknown — verify"),
            "role": "NEEDS REVIEW — extract from tweet text below",
            "city": "NEEDS REVIEW",
            "type": "NEEDS REVIEW",
            "apply_link": f"https://twitter.com/{author.get('username', 'i')}/status/{tweet_id}",
            "source": "x_search",
            "source_tweet_id": tweet_id,
            "raw_text": tweet["text"],
            "captured_date": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
        })
        added += 1

    save_pending(pending)
    print(f"Added {added} new candidate listing(s) to {PENDING_FILE}. "
          f"Total pending review: {len(pending)}.")


if __name__ == "__main__":
    main()
